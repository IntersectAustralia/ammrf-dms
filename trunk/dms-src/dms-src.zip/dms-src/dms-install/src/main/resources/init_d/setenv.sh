# dms config location
JAVA_OPTS="$JAVA_OPTS -Ddms.config.home=_DMS_CONFIG_HOME_ -Ddms.keystore.pass=_DMS_KEYSTORE_PASS_ -Dsolr.solr.home=_DMS_CONFIG_HOME_/solr"
