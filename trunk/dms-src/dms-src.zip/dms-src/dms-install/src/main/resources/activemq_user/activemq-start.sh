#!/bin/bash
export JAVA_HOME="_JAVA_HOME_"
export JDK_HOME="_JAVA_HOME_"
export ActiveMQ="_ACTIVEMQ_HOME_"
$ActiveMQ/bin/activemq start
